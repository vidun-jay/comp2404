#include "Order.h"

/****************
 * CONSTRUCTORS *
 ****************/

Order::Order(const string& name, int menu_item, Location location)
    : name(name), menu_item(menu_item), location(location) {}

/*********************
 * GETTERS & SETTERS *
 *********************/

Location Order::getLocation() const { return this->location; }

/*********
 * OTHER *
 *********/

// TODO: finish
void Order::print() const {
    cout << "Name: " << name << endl;
}