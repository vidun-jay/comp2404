#ifndef BATTLE_H
#define BATTLE_H

#include "Character.h"

namespace Gondor {
    void fight(Character& fighter, Character& orc);
}

namespace Mordor {
    void fight(Character& fighter, Character& orc);
}

#endif // BATTLE_H